import Foundation
enum Color: String, CaseIterable{
    case black
    case white
    case yellow
    case red
    case blue
}
enum Accessories: String, CaseIterable {
    case noAccessories
    case alarm = "Cигнализация"
    case sportWheels = "Спортивные диски"
    case tinting = "Тонировка"
}
protocol Car {
    var model: String {get}
    var color: Color {get}
    var buildDate: Int {get}
    var price: Int {get set}
    var accessories: [Accessories] {get set}
    var isServiced: Bool {get set}
}
protocol Dealership {
    var name: String {get}
    var showroomCapacity: Int {get}
    var stockCars: [Car] {get set}
    var showroomCars: [Car] {get set}
    var cars: [Car] {get}

    func offerAccessories (_ accessories: [Accessories])
    func presaleService (_ auto: Car)
    func addToShowroom (_ auto: Car)
    func sellCar (_ auto: Car)
    func orderCar ()
}

struct Bmw: Car, Equatable{
    var model: String
    var color: Color
    var buildDate: Int
    var price: Int
    var accessories: [Accessories] = []
    var isServiced: Bool
}
extension Bmw {
    static func ==(lhs: Bmw, rhs: Bmw) -> Bool {
        return lhs.model == rhs.model &&
        lhs.color == rhs.color &&
        lhs.buildDate == rhs.buildDate &&
        lhs.price == rhs.price &&
        lhs.accessories == rhs.accessories &&
        lhs.isServiced == rhs.isServiced
    }
}
class DealerBmw: Dealership{
    var name: String = "Bmw"
    var showroomCapacity: Int = 5
    var showroomCars: [Car] = []
    var stockCars: [Car] = []
    var cars: [Car] = []
    var models = ["BMW X3M","BMW X5M","BMW M5","BMW 520i","BMW 730 Long"]

    func offerAccessories(_ accessories: [Accessories]) {
        print("Вы хотите приобрести что нибудь из \(accessories)?")
    }
    
    func presaleService(_ auto: Car) {
        
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            showroomCars[index].isServiced = true
            print("Автомобилю \(auto.model) проведена предпродажная подготовка")
        }
     
    }
    
    func addToShowroom(_ auto: Car) {
        
        if showroomCars.count != showroomCapacity {
            showroomCars.append(auto.self)
            presaleService(auto.self)
            if let index = stockCars.firstIndex(where: { $0.self == auto.self}) {
                stockCars.remove(at: index)
            }
            print("Авто \(auto.model) перемещена с парковки в салон.")
        } else {
            print("В автосалоне нет мест")
            
        }
    }
    
    func sellCar(_ auto: Car) {
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            if showroomCars[index].isServiced == false {
                presaleService(auto.self)
                }
            showroomCars.remove(at: index)
            print("Автомобиль \(auto.model) продан из салона, предпродажная подготовка проведена")
        } else {
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                if stockCars[index].isServiced == false {
                    presaleService(auto.self)
                    }
                stockCars.remove(at: index)
                print("Автомобиль \(auto.model) продан с парковки, предпродажная подготовка проведена")
            }
        }
    }
    func orderCar() {
        stockCars.append(Bmw(model: models.randomElement()!, color: Color.allCases.randomElement()!, buildDate: Int.random(in: 2019...2023), price: Int.random(in:  30000..<60000), isServiced: false))
    }
}
struct Lexus: Car {
    var model: String
    var color: Color
    var buildDate: Int
    var price: Int
    var accessories: [Accessories] = []
    var isServiced: Bool
}

class DealerLexus: Dealership{
    var name: String = "Lexus"
    var showroomCapacity: Int = 5
    var showroomCars: [Car] = []
    var stockCars: [Car] = []
    var cars: [Car] = []
    var models = ["NX 200","RX 350","GX 470","LX 570","is 300"]

    func offerAccessories(_ accessories: [Accessories]) {
        print("Вы хотите приобрести что нибудь из \(accessories)?")
    }
    
    func presaleService(_ auto: Car) {
        
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            showroomCars[index].isServiced = true
            print("Автомобилю \(auto.model) проведена предпродажная подготовка")
        }
     
    }
    
    func addToShowroom(_ auto: Car) {
        
        if showroomCars.count != showroomCapacity {
            showroomCars.append(auto.self)
            presaleService(auto.self)
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                stockCars.remove(at: index)
            }
            print("Авто \(auto.model) перемещена с парковки в салон.")
        } else {
            print("В автосалоне нет мест")
            
        }
    }
    
    func sellCar(_ auto: Car) {
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            if showroomCars[index].isServiced == false {
                presaleService(auto.self)
                }
            showroomCars.remove(at: index)
            print("Автомобиль \(auto.model) продан из салона, предпродажная подготовка проведена")
        } else {
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                if stockCars[index].isServiced == false {
                    presaleService(auto.self)
                    }
                stockCars.remove(at: index)
                print("Автомобиль \(auto.model) продан с парковки, предпродажная подготовка проведена")
            }
        }
    }
    func orderCar() {
        stockCars.append(Lexus(model: models.randomElement()!, color: Color.allCases.randomElement()!, buildDate: Int.random(in: 2019...2023), price: Int.random(in:  30000..<60000), isServiced: false))
    }
}
struct Toyota: Car {
    var model: String
    var color: Color
    var buildDate: Int
    var price: Int
    var accessories: [Accessories] = []
    var isServiced: Bool
}

class DealerToyota: Dealership{
    var name: String = "Toyota"
    var showroomCapacity: Int = 5
    var showroomCars: [Car] = []
    var stockCars: [Car] = []
    var cars: [Car] = []
    var models = ["Rav 4","LC 200","LC Prado","Camry","Corolla"]

    func offerAccessories(_ accessories: [Accessories]) {
        print("Вы хотите приобрести что нибудь из \(accessories)?")
    }
    
    func presaleService(_ auto: Car) {
        
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            showroomCars[index].isServiced = true
            print("Автомобилю \(auto.model) проведена предпродажная подготовка")
        }
     
    }
    
    func addToShowroom(_ auto: Car) {
        
        if showroomCars.count != showroomCapacity {
            showroomCars.append(auto.self)
            presaleService(auto.self)
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                stockCars.remove(at: index)
            }
            print("Авто \(auto.model) перемещена с парковки в салон.")
        } else {
            print("В автосалоне нет мест")
            
        }
    }
    
    func sellCar(_ auto: Car) {
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            if showroomCars[index].isServiced == false {
                presaleService(auto.self)
                }
            showroomCars.remove(at: index)
            print("Автомобиль \(auto.model) продан из салона, предпродажная подготовка проведена")
        } else {
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                if stockCars[index].isServiced == false {
                    presaleService(auto.self)
                    }
                stockCars.remove(at: index)
                print("Автомобиль \(auto.model) продан с парковки, предпродажная подготовка проведена")
            }
        }
    }
    func orderCar() {
        stockCars.append(Toyota(model: models.randomElement()!, color: Color.allCases.randomElement()!, buildDate: Int.random(in: 2019...2023), price: Int.random(in:  30000..<60000), isServiced: false))
    }
}
struct Porsche: Car {
    var model: String
    var color: Color
    var buildDate: Int
    var price: Int
    var accessories: [Accessories] = []
    var isServiced: Bool
}

class DealerPorsche: Dealership{
    var name: String = "Porsche"
    var showroomCapacity: Int = 5
    var showroomCars: [Car] = []
    var stockCars: [Car] = []
    var cars: [Car] = []
    var models = ["911","Panamera","Cayenne","Boxter","Macan","Taycan"]

    func offerAccessories(_ accessories: [Accessories]) {
        print("Вы хотите приобрести что нибудь из \(accessories)?")
    }
    
    func presaleService(_ auto: Car) {
        
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            showroomCars[index].isServiced = true
            print("Автомобилю \(auto.model) проведена предпродажная подготовка")
        }
     
    }
    
    func addToShowroom(_ auto: Car) {
        
        if showroomCars.count != showroomCapacity {
            showroomCars.append(auto.self)
            presaleService(auto.self)
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                stockCars.remove(at: index)
            }
            print("Авто \(auto.model) перемещена с парковки в салон.")
        } else {
            print("В автосалоне нет мест")
            
        }
    }
    
    func sellCar(_ auto: Car) {
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            if showroomCars[index].isServiced == false {
                presaleService(auto.self)
                }
            showroomCars.remove(at: index)
            print("Автомобиль \(auto.model) продан из салона, предпродажная подготовка проведена")
        } else {
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                if stockCars[index].isServiced == false {
                    presaleService(auto.self)
                    }
                stockCars.remove(at: index)
                print("Автомобиль \(auto.model) продан с парковки, предпродажная подготовка проведена")
            }
        }
    }
    func orderCar() {
        stockCars.append(Porsche(model: models.randomElement()!, color: Color.allCases.randomElement()!, buildDate: Int.random(in: 2019...2023), price: Int.random(in:  30000..<60000), isServiced: false))
    }
}
struct Tesla: Car {
    var model: String
    var color: Color
    var buildDate: Int
    var price: Int
    var accessories: [Accessories] = []
    var isServiced: Bool
}

class DealerTesla: Dealership{
    var name: String = "Tesla"
    var showroomCapacity: Int = 5
    var showroomCars: [Car] = []
    var stockCars: [Car] = []
    var cars: [Car] = []
    var models = ["Model S","Model 3","Model X","Model Y","Tesla CyberTrack"]

    func offerAccessories(_ accessories: [Accessories]) {
        print("Вы хотите приобрести что нибудь из \(accessories)?")
    }
    
    func presaleService(_ auto: Car) {
        
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            showroomCars[index].isServiced = true
            print("Автомобилю \(auto.model) проведена предпродажная подготовка")
        }
     
    }
    
    func addToShowroom(_ auto: Car) {
        
        if showroomCars.count != showroomCapacity {
            showroomCars.append(auto.self)
            presaleService(auto.self)
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                stockCars.remove(at: index)
            }
            print("Авто \(auto.model) перемещена с парковки в салон.")
        } else {
            print("В автосалоне нет мест")
            
        }
    }
    
    func sellCar(_ auto: Car) {
        if let index = showroomCars.firstIndex(where: { $0.model == auto.model}) {
            if showroomCars[index].isServiced == false {
                presaleService(auto.self)
                }
            showroomCars.remove(at: index)
            print("Автомобиль \(auto.model) продан из салона, предпродажная подготовка проведена")
        } else {
            if let index = stockCars.firstIndex(where: { $0.model == auto.model}) {
                if stockCars[index].isServiced == false {
                    presaleService(auto.self)
                    }
                stockCars.remove(at: index)
                print("Автомобиль \(auto.model) продан с парковки, предпродажная подготовка проведена")
            }
        }
    }
    func orderCar() {
        stockCars.append(Tesla(model: models.randomElement()!, color: Color.allCases.randomElement()!, buildDate: Int.random(in: 2019...2023), price: Int.random(in:  30000..<60000), isServiced: false))
    }
}
var bmwX3 = Bmw(model: "BMW X3", color: .black, buildDate: 2022, price: 50000, isServiced: false)
var dealerBmw = DealerBmw()
var dealerLexus = DealerLexus()
var dealerPorsche = DealerPorsche()
var dealerToyota = DealerToyota()
var dealerTesla = DealerTesla()
var dealers: [Dealership] = []
dealers.append(dealerBmw)
dealers.append(dealerTesla)
dealers.append(dealerLexus)
dealers.append(dealerToyota)
dealers.append(dealerPorsche)
for i in 0...dealers.count {
    if dealers[i].name == "Bmw" {
        print("\(dealers[i].name) - С удовольствием за рулем")
    } else if dealers[i].name == "Tesla" {
        print("\(dealers[i].name) - Мы не остановимся до тех пор, пока на дорогах не останутся одни электромобили")
    } else if dealers[i].name == "Toyota" {
        print("\(dealers[i].name) - Стремиться к лучшему")
    } else if dealers[i].name == "Lexus" {
        print("\(dealers[i].name) - Неудержимое стремление к совершенству")
    } else if dealers[i].name == "Porsche" {
        print("\(dealers[i].name) - Если рациональные аргументы идеально сочетаются с эмоциональными, это — наш шанс")
    }
}
dealerBmw.stockCars.append(bmwX3)
dealerBmw.addToShowroom(bmwX3)
//dealerBmw.offerAccessories(Accessories.allCases)
dealerBmw.sellCar(bmwX3)
dealerBmw.orderCar()
dealerBmw.orderCar()
dealerBmw.orderCar()
dealerBmw.orderCar()
dealerBmw.sellCar(dealerBmw.stockCars[1])
print(dealerBmw.stockCars.count)
dealerBmw.addToShowroom(dealerBmw.stockCars[0])
dealerBmw.addToShowroom(dealerBmw.stockCars[1])
print(dealerBmw.showroomCars)

